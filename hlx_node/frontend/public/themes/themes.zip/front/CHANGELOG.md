# CHANGELOG.md

## [2.0.0] - 2023-12-11

- Added 7 new pages
- Update dependencies

## [1.0.4] - 2023-10-04

- Update Twitter icon
- Update dependencies

## [1.0.2] - 2023-05-15

- Fix issue with clients carousel

## [1.0.1] - 2023-05-06

- Dependencies update

## [1.0.0] - 2023-04-19

First release
