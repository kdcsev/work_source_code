var is_test=true;

var QBApp = {
    appId: 63487,
    authKey: 'u4st6x7Nryyk2hE',
    authSecret: 'cBFsVfTzZSGfDtk'
};

var QB_Admin={
    id: 35000056,
    login: 'QB_Admin',
    pass: 'getappinstall'
};

if(is_test){
    QBApp = {
        appId: 63528,
        authKey: 'AOtKUZ3dZCgVk78',
        authSecret: 'VD2QgR3rZOaK7SO'
    };

    QB_Admin={
        id: 34999890,
        login: 'QB_Admin',
        pass: 'getappinstall'
    };
}


