---
order: 0
title:
  zh-CN: 基本
  en-US: Basic
---

## zh-CN

简单的展示。

## en-US

Simplest Usage.

```jsx
import { Empty } from 'antd';

ReactDOM.render(<Empty />, mountNode);
```
