# Scutum Admin template (HTML version)

## Quick Setup

``` bash
# install dependencies
$ yarn sc-setup

# serve with hot reload at 192.168.1.188:3101
$ yarn sc-serve

# build static HTML files (../dist)
$ yarn sc-build

```

For detailed explanation on how things work, check Scutum Admin documentation.
