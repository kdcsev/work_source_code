<div id="sc-page-wrapper">
	<div id="sc-page-content">

        <div class="uk-card">
            <div class="uk-card-body">
                <div id="sc-gantt-chart"></div>
            </div>
        </div>

	</div>
</div>
