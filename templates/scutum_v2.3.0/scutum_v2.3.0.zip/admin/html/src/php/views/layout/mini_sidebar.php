<div id="sc-page-wrapper">
	<div id="sc-page-content">
		Mini Sidebar example
	</div>
</div>