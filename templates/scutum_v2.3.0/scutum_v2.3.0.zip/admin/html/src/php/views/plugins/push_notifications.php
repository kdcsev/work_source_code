<div id="sc-page-wrapper">
	<div id="sc-page-content">

        <div class="md-bg-light-blue-100" data-uk-alert>To use this feature you need to run this code on LOCALHOST or use HTTPS protocol.</div>

        <div class="uk-card">
            <div class="uk-card-body">
                <button class="sc-button sc-button-primary" id="sc-js-push-send">Send notification</button>
            </div>
        </div>

	</div>
</div>
