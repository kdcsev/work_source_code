<div id="sc-page-wrapper">
	<div id="sc-page-content">
		<div class="uk-card">
		    <div class="uk-card-body">
                <h1>Idle timeout</h1>
                <hr>
                <p class="uk-margin-remove">Keep your mouse and keyboard still!</p>
                <p class="uk-margin-remove">This plugin will display a modal to the user after 5 seconds of idleness.</p>
            </div>
		</div>
	</div>
</div>
