<div id="sc-page-wrapper">
	<div id="sc-page-content">
		Blank template
	</div>
</div>