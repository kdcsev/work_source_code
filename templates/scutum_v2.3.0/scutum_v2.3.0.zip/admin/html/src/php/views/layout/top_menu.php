<div id="sc-page-wrapper">
	<div id="sc-page-content">
		Top Menu example
	</div>
</div>