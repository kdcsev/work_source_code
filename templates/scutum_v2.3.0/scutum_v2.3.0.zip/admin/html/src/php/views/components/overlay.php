<div id="sc-page-wrapper">
	<div id="sc-page-content">
		<div class="uk-card">
            <h3 class="uk-card-title">
                Overlay
            </h3>
			<div class="uk-card-body">
                <div class="uk-flex uk-height-medium">
                    <button class="sc-button sc-js-content-overlay uk-margin-right">
                        Content overlay
                    </button>
                    <button class="sc-button sc-js-content-overlay-spinner uk-margin-right">
                        Content overlay + spinner
                    </button>
                    <button class="sc-button sc-js-page-overlay uk-margin-right">
                        Page overlay
                    </button>
                    <button class="sc-button sc-js-page-overlay-spinner">
                        Page overlay + spinner
                    </button>
                </div>
			</div>
		</div>
	</div>
</div>
