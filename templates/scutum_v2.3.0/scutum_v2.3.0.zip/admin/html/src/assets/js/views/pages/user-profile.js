scutum.pages.user_profile = {};
scutum.pages.user_profile.init = function () {
    scutum.require(['fileinput'], function () {
      console.log('fileinput loaded!')
    })
};
