scutum.dynamicFields = {};
scutum.dynamicFields.init = function () {
	// dynamic fields
	scutum.forms.common.dynamicFields(null, true);
};
