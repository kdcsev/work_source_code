<template>
	<h3 class="uk-card-title">
		<slot></slot>
	</h3>
</template>
