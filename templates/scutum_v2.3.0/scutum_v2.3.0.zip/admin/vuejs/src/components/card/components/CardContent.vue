<template>
	<div class="sc-card-content">
		<slot></slot>
	</div>
</template>
