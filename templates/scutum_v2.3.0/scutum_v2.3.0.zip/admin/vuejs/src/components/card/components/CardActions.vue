<template>
	<div class="sc-actions">
		<slot></slot>
	</div>
</template>
