<template>
	<div class="uk-card-body">
		<slot></slot>
	</div>
</template>
