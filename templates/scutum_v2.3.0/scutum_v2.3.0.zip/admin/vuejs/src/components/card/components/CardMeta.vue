<template>
	<div class="uk-text-meta">
		<slot></slot>
	</div>
</template>
