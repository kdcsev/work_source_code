import Vue from 'vue';

import Chart from './Chart'
export default Chart;
