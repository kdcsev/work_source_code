<template>
	<button class="sc-button" tabindex="-1" type="button">
		<slot></slot>
	</button>
</template>
