import VectorMap from './VectorMap'

export default VectorMap
export {
	VectorMap
}
