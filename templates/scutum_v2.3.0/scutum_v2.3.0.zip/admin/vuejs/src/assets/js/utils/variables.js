const scVars = {
	easingSwiftOut: [0.55, 0, 0.1, 1]
};

export default scVars;
