<template>
	<div id="sc-page-wrapper">
		<div id="sc-page-content">
			<div class="uk-child-width-1-2@l uk-grid" data-uk-grid>
				<div>
					<ScCard>
						<ScCardTitle>
							Default
						</ScCardTitle>
						<ScCardBody>
							<ul data-uk-tab>
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Bottom modifier
						</ScCardTitle>
						<ScCardBody>
							<ul class="uk-switcher sc-switcher-bottom">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
							<ul class="uk-tab-bottom" data-uk-tab="connect: .sc-switcher-bottom">
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
			</div>
			<div class="uk-child-width-1-2@l uk-grid" data-uk-grid>
				<div>
					<ScCard>
						<ScCardTitle>
							Left modifier
						</ScCardTitle>
						<ScCardBody>
							<div class="uk-grid-medium" data-uk-grid>
								<div class="uk-width-1-4@m">
									<ul class="uk-tab-left" data-uk-tab="connect: .sc-switcher-left">
										<li class="uk-active">
											<a href="javascript:void(0)">
												Item
											</a>
										</li>
										<li>
											<a href="javascript:void(0)">
												Item
											</a>
										</li>
										<li>
											<a href="javascript:void(0)">
												Item
											</a>
										</li>
										<li class="uk-disabled">
											<a>Disabled</a>
										</li>
									</ul>
								</div>
								<div class="uk-width-expand@m">
									<ul class="uk-switcher sc-switcher-left">
										<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
										<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
										<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
									</ul>
								</div>
							</div>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Right modifier
						</ScCardTitle>
						<ScCardBody>
							<div class="uk-child-width-1-2@m" data-uk-grid>
								<div class="uk-width-expand@m">
									<ul class="uk-switcher sc-switcher-right">
										<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
										<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
										<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
									</ul>
								</div>
								<div class="uk-width-1-4@m">
									<ul class="uk-tab-right" data-uk-tab="connect: .sc-switcher-right">
										<li class="uk-active">
											<a href="javascript:void(0)">
												Item
											</a>
										</li>
										<li>
											<a href="javascript:void(0)">
												Item
											</a>
										</li>
										<li>
											<a href="javascript:void(0)">
												Item
											</a>
										</li>
										<li class="uk-disabled">
											<a>Disabled</a>
										</li>
									</ul>
								</div>
							</div>
						</ScCardBody>
					</ScCard>
				</div>
			</div>
			<div class="uk-child-width-1-2@l uk-grid" data-uk-grid>
				<div>
					<ScCard>
						<ScCardTitle>
							Center
						</ScCardTitle>
						<ScCardBody>
							<ul class="uk-flex-center" data-uk-tab>
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Right
						</ScCardTitle>
						<ScCardBody>
							<ul class="uk-flex-right" data-uk-tab>
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Justify
						</ScCardTitle>
						<ScCardBody>
							<ul class="uk-child-width-expand" data-uk-tab>
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Dropdown
						</ScCardTitle>
						<ScCardBody>
							<ul data-uk-tab>
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										More <span class="uk-margin-small-left" data-uk-icon="icon: triangle-down"></span>
									</a>
									<div data-uk-dropdown="mode: click">
										<ul class="uk-nav uk-dropdown-nav">
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
										</ul>
									</div>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
			</div>
			<h4 class="uk-margin-large-top">
				Animations
			</h4>
			<div class="uk-child-width-1-3@l uk-child-width-1-2@m" data-uk-grid>
				<div>
					<ScCard>
						<ScCardBody>
							<ul data-uk-tab="animation: uk-animation-scale-up">
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardBody>
							<ul data-uk-tab="animation: uk-animation-slide-bottom-small">
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardBody>
							<ul data-uk-tab="animation: uk-animation-slide-right-small">
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardBody>
							<ul data-uk-tab="animation: uk-animation-slide-left-small, uk-animation-fade">
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardBody>
							<ul data-uk-tab="animation: uk-animation-scale-down, uk-animation-fade">
								<li class="uk-active">
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li>
									<a href="javascript:void(0)">
										Item
									</a>
								</li>
								<li class="uk-disabled">
									<a>Disabled</a>
								</li>
							</ul>
							<ul class="uk-switcher">
								<li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam dolores sit culpa, veritatis unde voluptates, libero ex. Magni, doloremque!</li>
								<li>Voluptatibus expedita omnis similique facilis? Quis sint, ab facere tempora recusandae quam repudiandae et, eligendi assumenda nisi beatae itaque, necessitatibus esse aliquam!</li>
								<li>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</li>
							</ul>
						</ScCardBody>
					</ScCard>
				</div>
			</div>
		</div>
	</div>
</template>
