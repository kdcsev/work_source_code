<template>
	<div id="sc-page-wrapper">
		<div id="sc-page-content">
			<h5 class="uk-heading-line">
				<span>Default grid</span>
			</h5>
			<div class="uk-child-width-1-2@s uk-child-width-1-4@m uk-grid" data-uk-grid="masonry: true">
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 100px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 130px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 150px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 160px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 120px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 140px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 200px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 180px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 140px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 200px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 180px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 140px">
						Item
					</ScCard>
				</div>
			</div>
			<h5 class="uk-heading-line uk-margin-large-top">
				<span>With Parallax</span>
			</h5>
			<div class="uk-child-width-1-2@s uk-child-width-1-4@m uk-grid" data-uk-grid="masonry: true; parallax: 120">
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 100px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 130px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 150px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 160px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 120px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 140px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 200px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 180px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 140px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 200px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 180px">
						Item
					</ScCard>
				</div>
				<div>
					<ScCard class="uk-flex uk-flex-center uk-flex-middle" style="height: 140px">
						Item
					</ScCard>
				</div>
			</div>
		</div>
	</div>
</template>
