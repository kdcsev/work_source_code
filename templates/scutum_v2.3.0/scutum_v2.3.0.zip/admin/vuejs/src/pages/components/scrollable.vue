<template>
	<div id="sc-page-wrapper">
		<div id="sc-page-content">
			<div class="uk-grid uk-child-width-1-2@m" data-uk-grid>
				<div>
					<ScCard>
						<ScCardTitle>
							Medium Height
						</ScCardTitle>
						<ScCardBody>
							<perfect-scrollbar class="uk-height-medium ps--active-y ps--focus">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias aut eligendi exercitationem facilis, fuga numquam odio perferendis perspiciatis quaerat veniam. Adipisci aliquam consequatur molestias non pariatur quibusdam veniam. Aliquid at cum dignissimos ducimus excepturi fugiat impedit inventore ipsam labore mollitia nisi, officia praesentium provident reiciendis reprehenderit repudiandae rerum saepe suscipit veniam, voluptatum! A consequuntur dolorum, enim libero modi nam odit perspiciatis placeat possimus, quasi rem, soluta veniam vero voluptatem voluptatibus. A assumenda, consequuntur cupiditate earum exercitationem ipsa nostrum odit, pariatur quae quidem quos, rem totam voluptas. Aliquid commodi cumque delectus deserunt dignissimos excepturi hic in ipsam iste, itaque magnam maiores, mollitia nam neque perferendis placeat quas reiciendis saepe, temporibus veritatis. Ad architecto beatae debitis delectus dolorem ea eos ipsam mollitia nam necessitatibus numquam officiis perferendis porro praesentium quas quibusdam, reiciendis sequi. Accusantium ad animi architecto aut autem beatae consequuntur cum cupiditate dicta distinctio eius eum exercitationem inventore ipsam ipsum itaque iusto minus mollitia nemo nesciunt non odio odit omnis quae quidem reiciendis, repellat sint sit soluta tenetur ullam vel vitae voluptate voluptatem voluptates voluptatibus voluptatum? Aut beatae dolor dolorum facere, fuga ipsam magnam modi necessitatibus neque nostrum obcaecati, placeat porro possimus quo repellendus tenetur unde vel. A aliquid, amet asperiores aspernatur at blanditiis consequuntur corporis debitis doloremque eligendi, esse fugit hic itaque magnam nam porro quaerat qui quis recusandae sequi unde voluptatem voluptatum. A accusamus, aliquam architecto cum dolorem eaque earum esse eum exercitationem, harum impedit ipsam iure laborum molestias neque nostrum praesentium quod rem tempore temporibus ullam vero voluptates?
							</perfect-scrollbar>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Small Height
						</ScCardTitle>
						<ScCardBody>
							<perfect-scrollbar class="uk-height-small">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur dolore fuga ipsam nobis tempora voluptas voluptatibus. Doloremque est fugit magni nisi praesentium quisquam ratione repellendus sapiente tenetur voluptatum. Atque dolorum est maxime repudiandae temporibus tenetur totam voluptatibus. A adipisci asperiores aspernatur at blanditiis consectetur, consequatur consequuntur debitis doloribus esse harum illo impedit ipsam iure libero mollitia natus nemo nihil nisi optio pariatur qui quidem recusandae, saepe sapiente sunt tempora unde velit voluptas voluptatem! Dolor earum facere ipsum minima nam officiis quisquam, repellendus vel. Aperiam cumque ea laboriosam magnam maxime mollitia nisi nostrum repellendus soluta voluptatibus! Doloribus ducimus illo magnam non officia perspiciatis praesentium ratione recusandae rem tempore temporibus, ullam vitae. Aliquam cum cumque eos iure iusto magni minima molestias, nesciunt obcaecati optio quae quaerat quod quos recusandae rem, veniam vitae. Aspernatur aut consequatur cumque debitis error excepturi facilis, illo incidunt iure laboriosam libero, molestias optio pariatur possimus recusandae, repellat repellendus reprehenderit saepe sed sequi totam voluptatem voluptates. Amet, dicta incidunt odio quaerat rem repellendus tenetur. Doloribus iusto qui quos rerum? Accusantium blanditiis, commodi deserunt, dolores eos est et eum expedita explicabo fuga id iusto molestias mollitia nobis nostrum officiis omnis optio pariatur quasi quia repellendus sapiente sequi ullam velit vero.
							</perfect-scrollbar>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Large Height
						</ScCardTitle>
						<ScCardBody>
							<perfect-scrollbar class="uk-height-large">
								Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam, aut consectetur dignissimos dolorum ducimus eligendi inventore ipsa, itaque magnam minus nam natus possimus quasi recusandae rerum sed voluptatum? Aliquid amet animi beatae blanditiis ea, eaque excepturi id incidunt, labore, libero mollitia necessitatibus neque optio perspiciatis praesentium quia quod quos reiciendis rem sed suscipit tempora tempore. Architecto, asperiores aut consequatur consequuntur culpa cumque debitis dolorum, eius eum fugiat libero magnam modi nam numquam quo quos rem veniam vitae voluptates voluptatum! Animi dolorem, eius excepturi, expedita illum ipsum magnam necessitatibus, obcaecati possimus quae quibusdam ratione repellat soluta vitae voluptatum. Dicta dolore ipsum saepe. Aut commodi corporis esse ex, excepturi iusto numquam officia sunt temporibus? Accusamus beatae eaque laudantium minus quae repudiandae tempora, temporibus vel voluptatibus. Ab accusantium, alias amet cum dolore doloribus eveniet facilis fugiat harum id impedit, inventore itaque laborum nihil odit, officia quia quibusdam sed vero voluptatibus! Ad, eius, id. Ab ad adipisci assumenda beatae deleniti dolore dolores eveniet exercitationem, expedita harum illo impedit iusto labore laboriosam, nesciunt nobis nulla numquam obcaecati praesentium quam quis quod rem repellat veniam voluptas voluptate voluptates voluptatibus? A aliquid assumenda consequatur consequuntur cum dolor earum eius et ex excepturi incidunt iusto labore, libero nam nemo omnis perspiciatis quae, quis quisquam rem repellat reprehenderit saepe vel, vitae voluptatem. Corporis debitis dolor eius facilis ipsam iste molestiae nisi sit vel, voluptatum? Corporis, cupiditate distinctio doloribus natus numquam quas recusandae suscipit ut vitae voluptas. Aliquam asperiores aut commodi consequatur debitis dolore earum eius error explicabo, facilis harum non pariatur quia quibusdam quod similique voluptas voluptatum. Deserunt dolores maiores omnis? Accusamus adipisci aliquam assumenda at aut beatae consequuntur cum delectus deleniti dicta doloremque doloribus earum eius fugiat fugit incidunt ipsa maxime minus modi nemo odit, officia perferendis quas quibusdam reiciendis rem repellendus sit tenetur unde ut veniam vero voluptas voluptate? At aut deleniti earum fuga iste iusto magnam magni molestiae nihil, quisquam quod ratione tempore veniam? Corporis illo, unde! Aliquid dolor dolorem eius, enim eveniet exercitationem fugit laboriosam magni mollitia nobis nostrum quasi, repellat saepe veritatis vero! Animi consectetur deleniti earum est eum, excepturi explicabo hic maxime nihil omnis optio porro quaerat, reiciendis rerum saepe sequi similique soluta temporibus ullam velit. Accusamus atque beatae cumque illo inventore porro quidem repellendus, veniam. Dignissimos distinctio iste, iusto molestiae mollitia neque quasi, quibusdam rem reprehenderit suscipit voluptate voluptatem! Amet assumenda ducimus et explicabo impedit ipsa ipsum officiis rem. Atque aut optio ut! Alias architecto, beatae distinctio dolorum enim facere facilis fugit minus obcaecati officia quidem repellat rerum voluptatem. A adipisci amet animi architecto aspernatur commodi cupiditate debitis deserunt doloribus dolorum ea eligendi est eum, eveniet exercitationem expedita explicabo facere hic id ipsa ipsam ipsum itaque iusto maiores nemo odit quae quam quidem recusandae reiciendis repellat saepe suscipit tempora tempore tenetur veritatis voluptatem! Ad amet aperiam dolores laudantium magni optio quam quia quidem, quo voluptas! A accusamus aliquid consequuntur corporis delectus, doloribus eius et explicabo fugit impedit libero magni maiores minus mollitia neque, placeat possimus quaerat quia rem sint sit tempore veritatis?
							</perfect-scrollbar>
						</ScCardBody>
					</ScCard>
				</div>
				<div>
					<ScCard>
						<ScCardTitle>
							Drop/Dropdown Scrollable
						</ScCardTitle>
						<ScCardBody>
							<div class="uk-grid uk-child-width-auto" data-uk-grid>
								<div>
									<button class="sc-button sc-button-default sc-button-outline" type="button">
										Drop
									</button>
									<div ref="psDropContainer" class="uk-drop" data-uk-drop="pos: bottom-left">
										<ScCard>
											<ScCardBody>
												<perfect-scrollbar ref="psDrop" class="uk-height-small">
													Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis fuga ipsa laudantium, maxime nulla officiis quisquam temporibus totam velit voluptatum! Accusamus consectetur, dignissimos in magnam maiores modi necessitatibus neque nesciunt numquam obcaecati odio odit pariatur perferendis possimus provident quas quos sapiente sed sit voluptatibus. Ab ad amet autem cumque doloremque ea hic illo in, iste modi neque, non officia rem sit sunt tempore vel veritatis. Dolores explicabo fugiat laboriosam, nobis perferendis reiciendis sit vero. Commodi consectetur consequuntur dolore doloremque eum eveniet fugiat laborum laudantium magni molestias neque praesentium similique sunt temporibus, ut vel, voluptatibus? Alias amet ducimus perspiciatis quidem quos!
												</perfect-scrollbar>
											</ScCardBody>
										</ScCard>
									</div>
								</div>
								<div>
									<button class="sc-button sc-button-default sc-button-outline" type="button">
										Dropdown
									</button>
									<div ref="psDropdownContainer" class="uk-dropdown-small uk-dropdown" data-uk-dropdown="pos: bottom-left">
										<perfect-scrollbar ref="psDropdown" class="uk-nav uk-dropdown-nav uk-height-small" tag="ul">
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li class="uk-nav-header">
												Header
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li class="uk-nav-divider"></li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
											<li>
												<a href="javascript:void(0)">
													Item
												</a>
											</li>
										</perfect-scrollbar>
									</div>
								</div>
							</div>
						</ScCardBody>
					</ScCard>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
require('~/plugins/scrollable');
export default {
	mounted () {
		const self = this;
		// update drop container
		UIkit.util.on(self.$refs.psDropContainer, 'shown', function () {
			self.$refs.psDrop.ps.update()
		});
		// update dropdown container
		UIkit.util.on(self.$refs.psDropdownContainer, 'shown', function () {
			self.$refs.psDropdown.ps.update()
		});
	}
}
</script>
