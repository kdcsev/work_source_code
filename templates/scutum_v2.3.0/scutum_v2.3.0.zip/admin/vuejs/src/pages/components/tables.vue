<template>
	<div id="sc-page-wrapper">
		<div id="sc-page-content">
			<ScCard>
				<ScCardTitle>
					Default
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table">
							<caption>Table Caption</caption>
							<thead>
								<tr>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<td>Table Footer</td>
									<td>Table Footer</td>
									<td>Table Footer</td>
								</tr>
							</tfoot>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Table divider
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-divider">
							<thead>
								<tr>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Table striped
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-striped">
							<thead>
								<tr>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Table hover
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-hover uk-table-divider">
							<thead>
								<tr>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Size modifiers
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-small uk-table-divider">
							<thead>
								<tr>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
							</tbody>
						</table>
					</div>
					<hr>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-large uk-table-divider">
							<thead>
								<tr>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
									<th class="uk-text-nowrap">
										Table Heading
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Justify modifier
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-justify uk-table-divider">
							<thead>
								<tr>
									<th class="uk-width-small">
										Table Heading
									</th>
									<th>Table Heading</th>
									<th class="uk-table-shrink uk-text-nowrap">
										Heading
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</td>
									<td>
										<button class="sc-button sc-button-primary" type="button">
											Button
										</button>
									</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</td>
									<td>
										<button class="sc-button sc-button-primary" type="button">
											Button
										</button>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Alignment modifier
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-middle uk-table-divider">
							<thead>
								<tr>
									<th class="uk-width-small">
										Table Heading
									</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</td>
									<td>
										<button class="sc-button sc-button-secondary" type="button">
											Button
										</button>
									</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</td>
									<td>
										<button class="sc-button sc-button-secondary" type="button">
											Button
										</button>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Responsive
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-small uk-table-divider">
							<thead>
								<tr>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
									<th>Table Heading</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
								<tr>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
									<td>Table Data</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Stack on small viewports
				</ScCardTitle>
				<ScCardBody>
					<table class="uk-table uk-table-responsive uk-table-divider">
						<thead>
							<tr>
								<th>Table Heading</th>
								<th>Table Heading</th>
								<th>Table Heading</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Table Data</td>
								<td>Table Data</td>
								<td>Table Data</td>
							</tr>
							<tr>
								<td>Table Data</td>
								<td>Table Data</td>
								<td>Table Data</td>
							</tr>
							<tr>
								<td>Table Data</td>
								<td>Table Data</td>
								<td>Table Data</td>
							</tr>
						</tbody>
					</table>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Column width modifier
				</ScCardTitle>
				<ScCardBody>
					<table class="uk-table uk-table-divider">
						<thead>
							<tr>
								<th class="uk-table-shrink">
									Shrink
								</th>
								<th class="uk-table-expand">
									Expand
								</th>
								<th class="uk-width-small">
									Width Small
								</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>Table Data</td>
								<td>Table Data</td>
								<td>Table Data</td>
							</tr>
							<tr>
								<td>Table Data</td>
								<td>Table Data</td>
								<td>Table Data</td>
							</tr>
						</tbody>
					</table>
				</ScCardBody>
			</ScCard>
			<ScCard class="uk-margin-top">
				<ScCardTitle>
					Utilities
				</ScCardTitle>
				<ScCardBody>
					<div class="uk-overflow-auto">
						<table class="uk-table uk-table-hover uk-table-middle uk-table-divider">
							<thead>
								<tr>
									<th class="uk-table-shrink">
										<PrettyCheck v-model="table.checkAll" class="p-icon" :indeterminate.sync="table.checkAllInd" @change="checkAll($event)">
											<i slot="extra" class="icon mdi mdi-check"></i>
											<i slot="indeterminate-extra" class="icon mdi mdi-minus"></i>
											<label slot="indeterminate-label"></label>
										</PrettyCheck>
									</th>
									<th class="uk-table-shrink">
										Preserve
									</th>
									<th class="uk-table-expand">
										Expand + Link
									</th>
									<th class="uk-width-small">
										Truncate
									</th>
									<th class="uk-table-shrink uk-text-nowrap">
										Shrink + Nowrap
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<PrettyCheck v-model="table.checkboxes.cb1" class="p-icon" @change="setMainCheckbox($event)">
											<i slot="extra" class="icon mdi mdi-check"></i>
										</PrettyCheck>
									</td>
									<td><ScAvatar :avatar-id="2" size="md" class="uk-preserve-width"></ScAvatar></td>
									<td class="uk-table-link">
										<a class="uk-link-reset" href="javascript:void(0)">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
										</a>
									</td>
									<td class="uk-text-truncate">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
									</td>
									<td class="uk-text-nowrap">
										Lorem ipsum dolor
									</td>
								</tr>
								<tr>
									<td>
										<PrettyCheck v-model="table.checkboxes.cb2" class="p-icon" @change="setMainCheckbox($event)">
											<i slot="extra" class="icon mdi mdi-check"></i>
										</PrettyCheck>
									</td>
									<td><ScAvatar :avatar-id="4" size="md" class="uk-preserve-width"></ScAvatar></td>
									<td class="uk-table-link">
										<a class="uk-link-reset" href="javascript:void(0)">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
										</a>
									</td>
									<td class="uk-text-truncate">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
									</td>
									<td class="uk-text-nowrap">
										Lorem ipsum dolor
									</td>
								</tr>
								<tr>
									<td>
										<PrettyCheck v-model="table.checkboxes.cb3" class="p-icon" @change="setMainCheckbox($event)">
											<i slot="extra" class="icon mdi mdi-check"></i>
										</PrettyCheck>
									</td>
									<td><ScAvatarInitials initials="ge" size="md" class="md-bg-teal-600 md-color-white"></ScAvatarInitials></td>
									<td class="uk-table-link">
										<a class="uk-link-reset" href="javascript:void(0)">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
										</a>
									</td>
									<td class="uk-text-truncate">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
									</td>
									<td class="uk-text-nowrap">
										Lorem ipsum dolor
									</td>
								</tr>
								<tr>
									<td>
										<PrettyCheck v-model="table.checkboxes.cb4" class="p-icon" @change="setMainCheckbox($event)">
											<i slot="extra" class="icon mdi mdi-check"></i>
										</PrettyCheck>
									</td>
									<td><ScAvatar :avatar-id="3" size="md" class="uk-preserve-width"></ScAvatar></td>
									<td class="uk-table-link">
										<a class="uk-link-reset" href="javascript:void(0)">
											Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
										</a>
									</td>
									<td class="uk-text-truncate">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.
									</td>
									<td class="uk-text-nowrap">
										Lorem ipsum dolor
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</ScCardBody>
			</ScCard>
		</div>
	</div>
</template>

<script>
import ScAvatar from '~/components/Avatar'
import ScAvatarInitials from '~/components/AvatarInitials'
import PrettyCheck from 'pretty-checkbox-vue/check';

export default {
	components: {
		ScAvatar,
		ScAvatarInitials,
		PrettyCheck
	},
	data: () => ({
		table: {
			checkAll: false,
			checkAllInd: false,
			checkboxes: {
				cb1: false,
				cb2: false,
				cb3: false,
				cb4: false
			}
		}
	}),
	methods: {
		checkAll (state) {
			Object.keys(this.table.checkboxes).forEach((k) => {
				this.table.checkboxes[k] = state;
			});
		},
		setMainCheckbox () {
			var checkboxes = Object.keys(this.table.checkboxes).map((k) => {
				return this.table.checkboxes[k]
			});
			const someChecked = checkboxes.some(cb => cb === true);
			const allChecked = checkboxes.every(cb => cb === true);
			if (allChecked) {
				this.table.checkAll = true;
				this.table.checkAllInd = false
			} else if (someChecked) {
				this.table.checkAllInd = true
			} else {
				this.table.checkAll = false;
				this.table.checkAllInd = false
			}
		}
	}
}
</script>

<style lang="scss">
	@import '~scss/vue/_pretty_checkboxes';
</style>
