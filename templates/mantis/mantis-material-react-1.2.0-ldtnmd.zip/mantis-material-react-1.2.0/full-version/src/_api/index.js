// auth pages
import './account';

// app pages
import './billing-address';
import './chat';
import './cart';
import './calendar';
import './products';
import './product-reviews';
import './kanban';
